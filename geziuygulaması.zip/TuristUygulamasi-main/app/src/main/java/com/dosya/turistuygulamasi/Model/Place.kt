package com.cihan.turistuygulamasi.Model

class Place(val ad : String,val mekanAdi : String, val mekanTarih: String ,val  gorselUrl : String, val adres : String, val link : String? ) {


}