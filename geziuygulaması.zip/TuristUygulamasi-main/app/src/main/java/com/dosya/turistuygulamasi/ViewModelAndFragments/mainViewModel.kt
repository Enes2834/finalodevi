package com.cihan.turistuygulamasi.ViewModelAndFragments

import androidx.lifecycle.ViewModel


class mainViewModel : ViewModel() {


}