package com.cihan.turistuygulamasi.Model

class Advice(var adviceText : String,var adviceGorselUrl : String) {
}