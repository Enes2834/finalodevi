package com.cihan.turistuygulamasi.Model

class Food(val restoran : String, val yemekIsmi : String , val Bilgi : String, val resimUrl : String,val adres : String, val kaynak : String) {
}