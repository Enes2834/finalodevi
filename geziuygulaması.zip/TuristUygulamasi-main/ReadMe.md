## Importance Level High (4 Point) 
## Travel Guide Application.
###### What's inside?
My first application's Alpha Version.
- MVVM architecture
- Picasso
- Navigation
- Firebase (but no access file because security)
- BottomBar
- RecyclerView

Beta Version will be able to access on Google Play Store And Apple Store

Alpha Version
![alt text](https://github.com/CihanEksiogluBloo/TuristUygulamasi/blob/main/örnek.jpg?raw=true)
